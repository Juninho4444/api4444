<?php
// api.php

header("Content-Type: application/json; charset=utf-8");
$json_file = "jogos.json";

if (!file_exists($json_file)) {
    echo json_encode(["erro" => "Arquivo de dados não encontrado."]);
    exit;
}

echo file_get_contents($json_file);
?>